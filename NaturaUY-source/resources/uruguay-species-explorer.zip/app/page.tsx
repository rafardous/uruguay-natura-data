import { SpeciesExplorer } from '@/components/species-explorer'

export default function Page() {
  return <SpeciesExplorer />
}
